#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Apr 25 11:15:25 2018

@author: cao
"""

import pandas as pd
import numpy as np
from tqdm import tqdm
dir="/Users/cao/Desktop/DS Spring/EDVA/shiny/"
data1 = pd.read_csv(dir + "daily_avg_all.csv" )
position = pd.read_csv(dir + "long_lat.csv" )
position2 = pd.read_csv(dir + "NYC_Transit_Subway_Entrance_And_Exit_Data.csv" )
position2 = position2.iloc[:,2:5]

def iterative_levenshtein(s, t):
    rows = len(s)+1
    cols = len(t)+1
    dist = [[0 for x in range(cols)] for x in range(rows)]
    # source prefixes can be transformed into empty strings 
    # by deletions:
    for i in range(1, rows):
        dist[i][0] = i
    # target prefixes can be created from an empty source string
    # by inserting the characters
    for i in range(1, cols):
        dist[0][i] = i
        
    for col in range(1, cols):
        for row in range(1, rows):
            if s[row-1] == t[col-1]:
                cost = 0
            else:
                cost = 1
            dist[row][col] = min(dist[row-1][col] + 1,      # deletion
                                 dist[row][col-1] + 1,      # insertion
                                 dist[row-1][col-1] + cost) # substitution
    
 
    return dist[row][col]

def similarityname(name1,name2):
    s1=set(getWords(name1.lower()))
    s2 =set(getWords(name2.lower()))
    intersect = s1.intersection(s2)
    n1 = len(s1)
    n2 = len(s2)
    ninser = len(intersect)
    return min(ninser/n1,ninser/n2)

def similaritywebsite(s1,s2):
    s1=set(getWords(s1.lower()))
    s2 =set(getWords(s2.lower()))
    optimal= list()
    for i in s1:
        for j in s2:
            optimal.append(iterative_levenshtein(i, j))
    minimalcost = min(optimal)
    return np.exp(-0.1*minimalcost)

def getWords(text):

    return ''.join((c if c.isalnum() else ' ') for c in text).split()

for i in tqdm(range(len(position["Station.Name"]))):
    position["Station.Name"][i] = position["Station.Name"][i].replace('Av','AVE').replace('St','ST').replace('th','') \
    .replace('rd','').replace('nd','').replace("I","1")
    
for i in tqdm(range(len(position2["Station Name"]))):
    position2["Station Name"][i] = position2["Station Name"][i].replace('Av','AVE').replace('St','ST').replace('th','') \
    .replace('rd','').replace('nd','').replace("I","1")
    

suitname = list()
lon = list()
lat = list()
for i in tqdm(range(len(data1["STATION"]))):
    name = data1["STATION"][i]
    temp = 0
    tempindex = 0
    for j in range(len(position2["Station Name"])):
        similarity = similarityname(name,position2["Station Name"][j])
        if similarity>temp:
            temp = similarity
            tempindex = j
    suitname.append(position2["Station Name"][tempindex])
    lat.append(position2["Station Latitude"][tempindex])
    lon.append(position2["Station Longitude"][tempindex])
d = {"STATION":suitname, "BUSYNESS":data1["BUSYNESS"],"Station.Latitude":lat,"Station.Longitude":lon}
result = pd.DataFrame(data = d)
        